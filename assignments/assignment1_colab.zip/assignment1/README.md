## Assignment Instructions
Details about this assignment can be found [on the course webpage](https://courses.cs.washington.edu/courses/cse493g1/24wi/assignments/) for Winter '24, under Assignment 1.


Please examine `collect_submission.ipynb` for detailed submission instructions.