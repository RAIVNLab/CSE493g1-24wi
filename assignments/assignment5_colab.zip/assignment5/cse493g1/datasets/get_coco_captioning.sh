wget "https://courses.cs.washington.edu/courses/cse493g1/23sp/resources/coco_captioning.zip"
unzip coco_captioning.zip
rm coco_captioning.zip
