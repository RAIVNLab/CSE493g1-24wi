wget https://courses.cs.washington.edu/courses/cse493g1/23sp/resources/imagenet_val_25.npz
